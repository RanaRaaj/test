<?php

namespace App\Http\Controllers\Asset;

use App\Http\Controllers\Controller;
use App\Models\Asset;
use Illuminate\Http\Request;
use Auth;

class AssetController extends Controller
{
    //
    public function index()
    {
        $data = Asset::orderBy('id','DESC')->get()->all();
        return view('dashboard', compact('data'));
    }

    public function create_single_collectible(Request $request)
    {
        if ($request->hasFile('file')) {
            $image = $request->file('file');
            $file = time() . '1' . "." . $image->extension();
            $imagePath = public_path() . '/images';
            $image->move($imagePath, $file);
            $request['pre_gig_photo_1'] = $file;
        }
        Asset::create([
            'owner' => Auth::User()->name,
            'owner_id' => Auth::id(),
            'name' => $request->name,
            'description' => $request->description,
            'copies' => $request->copy,
            'royality' => $request->royality,
            'type' => $request->type,
            'price' => $request->price,
            'file' => $file ?? '',
        ]);
        return redirect('/dashboard');
    }
}
